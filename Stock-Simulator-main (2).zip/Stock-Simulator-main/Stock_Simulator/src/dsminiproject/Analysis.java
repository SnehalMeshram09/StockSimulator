package dsminiproject;

public class Analysis {

}
